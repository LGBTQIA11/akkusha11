-- Run once on the EXISTING D1 database used by the current Akkusha site.
-- The old Like API is removed from the application. The legacy like_count column is left untouched only to avoid destructive changes to existing rows.
ALTER TABLE works ADD COLUMN body TEXT NOT NULL DEFAULT '';
ALTER TABLE works ADD COLUMN view_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE works ADD COLUMN play_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE works ADD COLUMN read_count INTEGER NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS site_stats (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  visit_count INTEGER NOT NULL DEFAULT 0,
  follower_count INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO site_stats (id, visit_count, follower_count) VALUES (1,0,0);
CREATE TABLE IF NOT EXISTS contest_submissions (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  artist_name TEXT NOT NULL DEFAULT '',
  country TEXT NOT NULL,
  email TEXT NOT NULL,
  bio TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  file_key TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'received',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
DROP TABLE IF EXISTS user_likes;
