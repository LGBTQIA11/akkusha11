# Akkusha — final CMS + Contest package

Bu paket mövcud Akkusha saytının görünüşünü əsasən qoruyur: arxa fon, `In Akkusha flow....` düyməsi, menyu düymələri və `Contest` keçidi saxlanılır. Mövcud Contest PDF-i də saxlanılır.

## Nə artıq işləyir

### 1. Telefonla sayt idarəetməsi
`/admin.html` → Admin şifrəsi ilə daxil olun.

- Music: audio faylı telefondan yüklə + ad + izah → Yayımla
- Photography: foto yüklə + ad + izah → Yayımla
- Astronomy / Ufology: məqalə mətnini əlavə et → Yayımla
- Məzmunu redaktə et, gizlət, yenidən yayımla və sil
- Yeni əsər üçün artıq ZIP/deploy lazım deyil

### 2. Contest
`https://www.akkusha.com/Contest` yolu saxlanılır.

- Rəsmi PDF oxuma/yükləmə düymələri saxlanılır
- Kişi iştirakçı formadan fotoşəklini birbaşa yükləyir
- Ad, Artist name, ölkə, e-poçt, bio, əsər adı və əsər izahı göndərilir
- Uğurlu göndərişdən sonra “Hey Boy! Thank you for participating in the Men Loving Men competition.” mesajı göstərilir
- Foto R2-də saxlanılır, D1-də yalnız təqdimat məlumatı saxlanılır
- Admin Panel → Contest bölməsindən iştirakçı məlumatlarına baxmaq və fotoşəkli telefona yükləmək olur
- R2 faylları ictimai qovluq kimi açılmır; yükləmə Admin sessiyası ilə qorunur

### 3. Anonim statistika
İstifadəçi adı, profil və izləyici siyahısı saxlanmır.

- Audio: plays
- Foto: views
- Məqalə: reads
- Sayt: visits
- Follow: sayğac yalnız admin paneldə görünür; ictimai saytda Follow kvadratı və rəqəmi göstərilmir

## Bir dəfəlik Cloudflare qurulumu

Mövcud D1 və R2 binding-ləri qoruyun:
- D1 binding: `DB`
- R2 binding: `MEDIA`
- Secret: `ADMIN_TOKEN`

R2 bucket: `akkusha-media`.

Mövcud D1 `akkusha-likes` bazasına **migration.sql** faylını bir dəfə tətbiq edin. Əvvəlki migration artıq tətbiq olunubsa, yalnız **migration_artist_name.sql** faylını bir dəfə tətbiq edin. Bu migration Like cədvəlini silir və CMS/statistika/Contest cədvəllərini əlavə edir. Legacy `like_count` sütunu mövcud məlumatların təhlükəsizliyi üçün saxlanır, lakin tətbiq artıq onu istifadə etmir.

Sonra Worker + Assets paketini bir dəfə deploy edin. Bundan sonra yeni musiqi/foto/məqalə üçün ZIP lazım deyil.
