# Akkusha — deploy

This project is a Cloudflare Worker + Workers Assets project.

## Required Cloudflare resources
- D1 binding `DB` -> database `akkusha-likes`
- R2 binding `MEDIA` -> bucket `akkusha-media`
- Worker secret `ADMIN_TOKEN` -> your private admin password

## Deploy
From this project root:

```bash
npm install
npx wrangler deploy
```

Do NOT use the static/asset-only uploader for this project.

## URLs
- Site: https://www.akkusha.com/
- Admin: https://www.akkusha.com/admin.html
- Contest: https://www.akkusha.com/Contest

`/Contest` is explicitly routed to the bundled `/public/Contest/index.html`.

## D1
If the existing D1 database already has the required columns/tables, do not rerun destructive migrations. For a new database, use `schema.sql`.
