-- Run once on the existing Akkusha D1 database after the previous migration.sql.
ALTER TABLE contest_submissions ADD COLUMN artist_name TEXT NOT NULL DEFAULT '';
